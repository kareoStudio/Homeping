package com.example.geofence

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.HomePingApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val database = (context.applicationContext as HomePingApp).database
            CoroutineScope(Dispatchers.IO).launch {
                val settings = database.settingsDao().getSettings()
                if (settings != null && settings.isMonitoringActive) {
                    GeofenceHelper.setupGeofence(context, settings)
                }
            }
        }
    }
}
