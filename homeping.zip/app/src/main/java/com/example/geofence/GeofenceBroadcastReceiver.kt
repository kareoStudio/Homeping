package com.example.geofence

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.telephony.SmsManager
import androidx.core.app.NotificationCompat
import com.example.HomePingApp
import com.example.MainActivity
import com.example.R
import com.example.data.HistoryEntity
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class GeofenceBroadcastReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val geofencingEvent = GeofencingEvent.fromIntent(intent)
        if (geofencingEvent == null || geofencingEvent.hasError()) {
            return
        }

        val geofenceTransition = geofencingEvent.geofenceTransition
        val database = (context.applicationContext as HomePingApp).database
        val settingsDao = database.settingsDao()
        val historyDao = database.historyDao()

        CoroutineScope(Dispatchers.IO).launch {
            val settings = settingsDao.getSettings() ?: return@launch

            if (!settings.isMonitoringActive || settings.phoneNumber.isBlank()) return@launch

            val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val calendar = Calendar.getInstance()
            val currentHour = calendar.get(Calendar.HOUR_OF_DAY)

            if (geofenceTransition == Geofence.GEOFENCE_TRANSITION_ENTER) {
                // Morning arrival check
                if (currentHour in settings.morningStartHour until settings.morningEndHour) {
                    if (settings.lastArrivalDate != todayStr) {
                        val message = "Main college aa gaya hoon 🏫"
                        sendSms(context, settings.phoneNumber, message)
                        settingsDao.insertOrUpdate(settings.copy(lastArrivalDate = todayStr))
                        historyDao.insertHistory(HistoryEntity(type = "ARRIVAL", message = message))
                        showNotification(context, "Arrived at College", message)
                    }
                }
            } else if (geofenceTransition == Geofence.GEOFENCE_TRANSITION_EXIT) {
                // Afternoon departure check
                if (currentHour in settings.afternoonStartHour until settings.afternoonEndHour) {
                    if (settings.lastDepartureDate != todayStr) {
                        val message = "Main college se nikal gaya hoon 🏠"
                        sendSms(context, settings.phoneNumber, message)
                        settingsDao.insertOrUpdate(settings.copy(lastDepartureDate = todayStr))
                        historyDao.insertHistory(HistoryEntity(type = "DEPARTURE", message = message))
                        showNotification(context, "Left College", message)
                    }
                }
            }
        }
    }

    private fun sendSms(context: Context, phoneNumber: String, message: String) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            showNotification(context, "Permission Denied", "Cannot send SMS. Please grant SMS permission.")
            return
        }
        try {
            val smsManager: SmsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                context.getSystemService(SmsManager::class.java)
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getDefault()
            }
            smsManager.sendTextMessage(phoneNumber, null, message, null, null)
        } catch (e: Exception) {
            e.printStackTrace()
            showNotification(context, "Failed to send SMS", "Error: ${e.message}")
        }
    }

    private fun showNotification(context: Context, title: String, message: String) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "homeping_channel"
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "HomePing Notifications", NotificationManager.IMPORTANCE_DEFAULT)
            notificationManager.createNotificationChannel(channel)
        }

        val intent = Intent(context, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_IMMUTABLE)

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(System.currentTimeMillis().toInt(), notification)
    }
}
