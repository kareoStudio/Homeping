package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "settings")
data class SettingsEntity(
    @PrimaryKey val id: Int = 1,
    val phoneNumber: String = "",
    val collegeLat: Double = 0.0,
    val collegeLng: Double = 0.0,
    val radius: Float = 150f,
    val morningStartHour: Int = 6,
    val morningEndHour: Int = 12,
    val afternoonStartHour: Int = 13,
    val afternoonEndHour: Int = 19,
    val lastArrivalDate: String = "",
    val lastDepartureDate: String = "",
    val isMonitoringActive: Boolean = false
)

@Entity(tableName = "history")
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val type: String, // "ARRIVAL" or "DEPARTURE"
    val message: String
)
