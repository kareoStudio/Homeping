package com.example

import android.app.Application
import com.example.data.AppDatabase

class HomePingApp : Application() {
    val database by lazy { AppDatabase.getDatabase(this) }
}
