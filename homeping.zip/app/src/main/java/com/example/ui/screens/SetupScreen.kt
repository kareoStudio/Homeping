package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.data.SettingsEntity
import com.google.android.gms.location.LocationServices

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SetupScreen(
    currentSettings: SettingsEntity?,
    onSave: (SettingsEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var phoneNumber by remember { mutableStateOf(currentSettings?.phoneNumber ?: "") }
    var radiusStr by remember { mutableStateOf((currentSettings?.radius ?: 150f).toInt().toString()) }
    var lat by remember { mutableStateOf(currentSettings?.collegeLat?.toString() ?: "0.0") }
    var lng by remember { mutableStateOf(currentSettings?.collegeLng?.toString() ?: "0.0") }
    
    var morningStartHour by remember { mutableStateOf(currentSettings?.morningStartHour?.toString() ?: "6") }
    var morningEndHour by remember { mutableStateOf(currentSettings?.morningEndHour?.toString() ?: "12") }
    var afternoonStartHour by remember { mutableStateOf(currentSettings?.afternoonStartHour?.toString() ?: "13") }
    var afternoonEndHour by remember { mutableStateOf(currentSettings?.afternoonEndHour?.toString() ?: "19") }

    var permissionsGranted by remember { mutableStateOf(checkPermissions(context)) }

    val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
    var isIgnoringBatteryOpt by remember { mutableStateOf(pm.isIgnoringBatteryOptimizations(context.packageName)) }

    val bgLocationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        permissionsGranted = checkPermissions(context)
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineLoc = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
        if (fineLoc && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            bgLocationLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        } else {
            permissionsGranted = checkPermissions(context)
        }
    }

    LaunchedEffect(Unit) {
        if (!permissionsGranted) {
            val permissionsToRequest = mutableListOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.SEND_SMS
            )
            if (Build.VERSION.SDK_INT == Build.VERSION_CODES.Q) {
                permissionsToRequest.add(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
            }
            permissionLauncher.launch(permissionsToRequest.toTypedArray())
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Welcome to HomePing", style = MaterialTheme.typography.headlineMedium)
        Text("Let's set up your college location and parent's phone number.", style = MaterialTheme.typography.bodyLarge)

        if (!permissionsGranted) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                PaddingValues(16.dp)
                Text(
                    "Please grant Location, Background Location, SMS, and Notification permissions for the app to work correctly.",
                    modifier = Modifier.padding(16.dp),
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
            }
        }

        if (!isIgnoringBatteryOpt) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "Battery Optimization",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onTertiaryContainer
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "To ensure background geofencing works reliably without sleeping, please ignore battery optimizations for this app.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onTertiaryContainer
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(onClick = {
                        val intent = android.content.Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                            data = Uri.parse("package:${context.packageName}")
                        }
                        context.startActivity(intent)
                    }) {
                        Text("Disable Optimization")
                    }
                }
            }
        }

        OutlinedTextField(
            value = phoneNumber,
            onValueChange = { phoneNumber = it },
            label = { Text("Parent's Phone Number") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = radiusStr,
            onValueChange = { radiusStr = it },
            label = { Text("Geofence Radius (meters)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )

        Text("College Location", style = MaterialTheme.typography.titleMedium)

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = lat,
                onValueChange = { lat = it },
                label = { Text("Latitude") },
                modifier = Modifier.weight(1f),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
            )
            OutlinedTextField(
                value = lng,
                onValueChange = { lng = it },
                label = { Text("Longitude") },
                modifier = Modifier.weight(1f),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
            )
        }

        Button(
            onClick = {
                val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)
                try {
                    fusedLocationClient.lastLocation.addOnSuccessListener { location ->
                        if (location != null) {
                            lat = location.latitude.toString()
                            lng = location.longitude.toString()
                        }
                    }
                } catch (e: SecurityException) {
                    // Ignore or handle
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.LocationOn, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Use Current Location")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Time Windows (24-Hour Format)", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = morningStartHour,
                onValueChange = { morningStartHour = it },
                label = { Text("Morn Start") },
                modifier = Modifier.weight(1f),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            OutlinedTextField(
                value = morningEndHour,
                onValueChange = { morningEndHour = it },
                label = { Text("Morn End") },
                modifier = Modifier.weight(1f),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = afternoonStartHour,
                onValueChange = { afternoonStartHour = it },
                label = { Text("Aft Start") },
                modifier = Modifier.weight(1f),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            OutlinedTextField(
                value = afternoonEndHour,
                onValueChange = { afternoonEndHour = it },
                label = { Text("Aft End") },
                modifier = Modifier.weight(1f),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                val r = radiusStr.toFloatOrNull() ?: 150f
                val l1 = lat.toDoubleOrNull() ?: 0.0
                val l2 = lng.toDoubleOrNull() ?: 0.0
                val ms = morningStartHour.toIntOrNull() ?: 6
                val me = morningEndHour.toIntOrNull() ?: 12
                val as_start = afternoonStartHour.toIntOrNull() ?: 13
                val ae = afternoonEndHour.toIntOrNull() ?: 19

                val settings = currentSettings?.copy(
                    phoneNumber = phoneNumber,
                    radius = r,
                    collegeLat = l1,
                    collegeLng = l2,
                    morningStartHour = ms,
                    morningEndHour = me,
                    afternoonStartHour = as_start,
                    afternoonEndHour = ae
                ) ?: SettingsEntity(
                    phoneNumber = phoneNumber,
                    radius = r,
                    collegeLat = l1,
                    collegeLng = l2,
                    morningStartHour = ms,
                    morningEndHour = me,
                    afternoonStartHour = as_start,
                    afternoonEndHour = ae
                )
                onSave(settings)
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = phoneNumber.isNotBlank() && lat.toDoubleOrNull() != null && lng.toDoubleOrNull() != null
        ) {
            Text("Save & Continue")
        }
    }
}

private fun checkPermissions(context: Context): Boolean {
    val fineLoc = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    val bgLoc = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED
    } else true
    val sms = ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED
    
    return fineLoc && bgLoc && sms
}
