package com.example.ui.screens

import android.content.Context
import android.os.PowerManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.SettingsEntity
import com.example.data.HistoryEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    settings: SettingsEntity,
    recentHistory: List<HistoryEntity>,
    onToggleMonitoring: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
    val isIgnoringBatteryOpt = pm.isIgnoringBatteryOptimizations(context.packageName)

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (settings.isMonitoringActive && !isIgnoringBatteryOpt) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.onErrorContainer)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "Battery Optimization is enabled. Geofencing may not work in the background. Please disable it in Settings.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                }
            }
        }
        
        val monitoringColor = if (settings.isMonitoringActive) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
        
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = monitoringColor)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (settings.isMonitoringActive) "Monitoring Active 🟢" else "Monitoring Paused ⏸️",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                val maskedPhone = if (settings.phoneNumber.length > 4) {
                    "****" + settings.phoneNumber.takeLast(4)
                } else settings.phoneNumber
                
                Text("Home Number: $maskedPhone")
                Text("College: ${settings.collegeLat}, ${settings.collegeLng}")
                Text("Radius: ${settings.radius}m")
                Spacer(modifier = Modifier.height(16.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Enable Monitoring")
                    Switch(
                        checked = settings.isMonitoringActive,
                        onCheckedChange = { onToggleMonitoring(it) }
                    )
                }
            }
        }
        
        val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Today's Status", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                
                StatusRow(
                    label = "Morning Arrival",
                    isComplete = settings.lastArrivalDate == todayStr
                )
                Spacer(modifier = Modifier.height(4.dp))
                StatusRow(
                    label = "Afternoon Departure",
                    isComplete = settings.lastDepartureDate == todayStr
                )
            }
        }
        
        Text("Recent Activity", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        
        LazyColumn(modifier = Modifier.fillMaxWidth()) {
            items(recentHistory.take(5)) { history ->
                HistoryItem(history)
            }
        }
    }
}

@Composable
fun StatusRow(label: String, isComplete: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            imageVector = if (isComplete) Icons.Default.CheckCircle else Icons.Default.Warning,
            contentDescription = null,
            tint = if (isComplete) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(label)
    }
}

@Composable
fun HistoryItem(history: HistoryEntity) {
    val dateStr = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault()).format(Date(history.timestamp))
    Column(modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 4.dp)) {
        Text(text = "$dateStr — ${if (history.type == "ARRIVAL") "Arrived" else "Left"} — Message Sent", style = MaterialTheme.typography.bodyMedium)
        Divider(modifier = Modifier.padding(top = 4.dp))
    }
}
