package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.HomePingApp
import com.example.data.HistoryEntity
import com.example.data.SettingsEntity
import com.example.geofence.GeofenceHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

import kotlinx.coroutines.flow.map

class HomePingViewModel(application: Application) : AndroidViewModel(application) {
    private val database = (application as HomePingApp).database
    private val settingsDao = database.settingsDao()
    private val historyDao = database.historyDao()

    val settings: StateFlow<SettingsEntity?> = settingsDao.getSettingsFlow()
        .map { it ?: SettingsEntity() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val history: StateFlow<List<HistoryEntity>> = historyDao.getAllHistoryFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun updateSettings(newSettings: SettingsEntity) {
        viewModelScope.launch {
            settingsDao.insertOrUpdate(newSettings)
            if (newSettings.isMonitoringActive) {
                GeofenceHelper.setupGeofence(getApplication(), newSettings)
            } else {
                GeofenceHelper.removeGeofence(getApplication())
            }
        }
    }

    fun toggleMonitoring(isActive: Boolean) {
        val currentSettings = settings.value ?: return
        updateSettings(currentSettings.copy(isMonitoringActive = isActive))
    }
}
